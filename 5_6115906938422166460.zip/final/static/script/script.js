var zone = ["Cauvery Delta","North Eastern","Western","North Western","High Altitude","Southern","High Rainfall"];

var districts = {};

districts["Cauvery Delta"] = ["Thanjavur","Nagapattinam","Tiruvarur","Tiruchirapalli"];

districts["North Eastern"] = ["Kanchipuram","Tiruvallur","Vellore","Cuddalore","Delta_regions_of_Cuddalore","Villuparam","Tiruvannamalai"];

districts["Western"] = ["Coimbatore","Karur","Tiruppur","Perambalur","Delta regions of Karur","Delta regions of Ariyalur"];

districts["North Western"] = ["Salem","Namakkal","Krishnagiri","Dharmapuri"];

districts["High Altitude"] = ["Nilgiris"];

districts["Southern"] = ["Pudukottai","Delta regions of Pudukottai","Madurai","Ramanathapuram","Virudhunagar","Sivaganga","Tirunelveli","Dindigul","Thoothukudi"];

districts["High Rainfall"] = ["Kanyakumari"];

var season = {};

       season["Tiruvarur"] = ["Kuruvai", "Samba","Late Samba","Thaladi","Navarai","Semi dry cultivation in august","Semi dry cultivation in september","Flood affected areas","Salt affected areas"]
       season["Thanjavur"] = ["Kuruvai", "Samba","Late Samba","Thaladi","Navarai","Semi dry cultivation in august","Semi dry cultivation in september","Flood affected areas","Salt affected areas"]
       season["Nagapattinam"] = ["Late Kuruvai","Samba","Semi dry cultivation in august","Semi dry cultivation in september","Flood affected areas","Salt affected areas"]
       season["Tiruchirapalli"] = ["Kuruvai","Samba","Thaladi","Summer","Flood affected areas","Salt affected areas"]
       season["Kanchipuram"] = ["Sornavari","Samba","Late Samba","Navarai","Rainfed direct seeded","Semi-dry"]
       season["Tiruvallur"] = ["Sornavari","Samba","Late Samba","Navarai","Rainfed direct seeded","Semi-dry","Drought affected areas"]
       season["Vellore"] = ["Sornavari","Samba","Navarai"]
       season["Tiruvannamalai"] = ["Sornavari","Samba","Navarai"]
       season["Cuddalore"] = ["Sornavari","Samba","Navarai"]
       season["Villupuram"] = ["Sornavari","Samba","Navarai"]
       season["Delta regions of Cuddalore"] = ["Samba","Late samba","Thaladi","Salt affected areas (Cuddalore)"]
       season["Coimbatore"] = ["Kar","Samba" ,"Late Samba","Navarai"]
       season["Tiruppur"] = ["Kar","Samba" ,"Late Samba","Navarai"] 
       season["Erode"] = ["Kar","Samba" ,"Late Samba","Navarai"]
       season["Karur"] = ["Kuruvai","Samba","Late Samba","Thaladi","Navarai"]
       season["Delta regions of Karur"] =["Late Samba"]
       season["Perambalur"] = ["Kuruvai","Samba","Late Samba","Thaladi","Navarai"]
       season["Priyalur"] = ["Kuruvai","Samba","Late Samba","Thaladi","Navarai"]
       season["Delta regions of Ariyalur"] = ["Samba","Late samba","Thaladi"]
       season["Salem"] = ["Kar","Samba","Navarai"]
       season["Namakkal"] = ["Kar","Samba","Navarai"]
       season["Dharmapuri"] = ["Kar","Samba","Late Samba","Navarai"]
       season["Krishnagiri"] = ["Kar","Samba","Late Samba","Navarai"]
       season["Nilgiris"] = ["Samba"]
       season["Pudukottai"] = ["Kuruvai","Samba","Late Samba","Thaladi","Rainfed direct seeded","Semi-dry","Salt affected areas"]
       season["Delta regions of Pudukottai"] =["All seasons"]
       season["Madurai"] = ["Kar","Samba","Late Samba","Navarai","Semi-dry","Drought affected areas"]
       season["Dindigul"] = ["Kar","Samba","Late Samba","Navarai","Semi-dry"]
       season["Theni"] = ["Kar","Samba","Late Samba","Navarai","Semi-dry"] 
       season["Ramanathapuram"] = ["Samba","Rainfed direct seeded","Semi-dry","Drought affected areas"]
       season["Virudhunagar"] = ["Samba","Rainfed direct seeded","Drought affected areas"]
       season["Sivaganga"] = ["Semi-dry"]
       season["Tirunelveli"] = ["Early kar","Kar","Pishanam","Late Pishanam","Semi-dry"]
       season["Thoothukudi"] = ["Early kar","Kar","Pishanam","Late Pishanam","Semi-dry"] 
       season["Kanyakumari"] = ["Kar","Pishanam","Late samba","Semi-dry"]

       function addOpt(name,id) {
            var selector = document.querySelector(id);
            name.forEach((sel) => {
                var opt = document.createElement('option');
                opt.setAttribute("value", sel);
                opt.appendChild(document.createTextNode(sel));
                selector.appendChild(opt);
            })
       };

       addOpt(zone,".select-box1"); //add option for select tag

       //function to check and add option
       function selected(curr_div,target_div,diction){

            var select1 = document.querySelector(curr_div);
            var select2 = document.querySelector(target_div);
            var value = select1.options[select1.selectedIndex].value;

            while(select2.options[1]) {
                select2.remove(1);
            }

            var to_check = diction[value];

            if (to_check) {
                for (var i = 0; i<to_check.length; i++) {
                    var option_ = new Option(to_check[i], to_check[i]);
                    select2.options.add(option_);
                }
            }
       }