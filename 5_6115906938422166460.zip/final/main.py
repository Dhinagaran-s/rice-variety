from flask import Flask,redirect,render_template,url_for,request






dict1 = {}


dict1['row_1']= ('ADT 53','CO 51','ADT 43','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_2']= ('CR 1009 Sub1','TNAU Rice ADT 50','ADT 51','CR 1009','TRY 3')
dict1['row_3'] = ('VGD 1','TKM 13','CO 52','CO (R) 50','ADT 39','ADT 38','TNAU Rice ADT 49','CO 43','CO 43 sub.1','Imp.White Ponni','ADT (R) 46','TNAU Rice TRY 3*','TNAU Rice Hybrid CO 4')
dict1['row_4'] = ('ADT 53','CO 51','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_5'] = ('ADT(R)48','MDU 5','CO 51','ADT 53','ADT(R)45','ADT 37','ADT 36')
dict1['row_6'] = ('CR 1009 Sub1','TNAU Rice ADT 50','ADT 51','CR 1009','CO(R)50','CO 52','ADT (R)46','TKM 13','TNAU Rice TRY 3*','ADT 39','ADT 38','CO 43 sub 1','CO 43')
dict1['row_7'] = ('CR 1009','CR 1009 sub 1','ADT 51','TRY 3')
dict1['row_8'] = ('ADT 38','ADT 39','ADT 46','Co 50','Co 52','TKM 13','TRY 3')
dict1['row_9'] = ('ADT 53','CO 51','ADT 43','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9','TRY 2*')
dict1['row_10'] = ('CR 1009 Sub1','TNAU Rice ADT 50','ADT 51','CR 1009','TNAU Rice TRY 3*','TRY 1*','CO 43','TKM 13','VGD 1','CO 52','CO (R) 50','ADT 39','ADT 38','TNAU Rice ADT 49','Imp.White Ponni','ADT (R) 46','TNAU Rice Hybrid CO 4')
dict1['row_11'] = ('ADT 53','CO 51','ADT (R) 45','TPS 5','ADT 36','ADT 37','CORH 3','ASD 16')
dict1['row_12'] = ('CR 1009 sub1')
dict1['row_13'] = ('TRY 1','TRY 2','TRY 3','Co 43')
dict1['row_14'] = ('ADT 53','CO 51','ADT 43','ADT (R) 45','TPS 5','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_15'] = ('VGD 1','TKM 13','CO 52','CO (R) 50','ADT 39','ADT 38','TNAU Rice ADT 49','CO 43','Imp.White Ponni','ADT (R) 46','TNAU Rice TRY 3*','TNAU Rice Hybrid CO 4')
dict1['row_16'] = ('ADT 53','CO 51','ADT (R) 45','MDU 6','ADT 36','ADT 37','CORH 3','TKM 9')
dict1['row_17'] = ('Anna (R) 4','ADT 36','ADT 39','TKM 9','TKM 11')
dict1['row_18'] = ('Anna (R) 4','PMK 3')
dict1['row_19'] = ('ADT 53','CO 51','ADT 43','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_20'] = ('VGD 1','TKM 13','CO 52','Imp.White Ponni','ASD 19','TNAU Rice ADT 49','CO (R) 50','ADT 39','ADT 38','CO 43','ADT (R) 46','TNAU Rice Hybrid CO 4')
dict1['row_21'] = ('ADT 53','CO 51','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_22'] = ('ADT 53','CO 51','ADT 43','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_23'] = ('CR 1009 Sub1','TNAU Rice ADT 50','ADT 51','CR 1009','VGD 1','TKM 13','CO 52','Imp.White Ponni','TRY 3*','TNAU Rice Hybrid CO 4','CO (R) 50','TNAU Rice ADT 49','CO 43','TRY 1','ADT(R) 46','ADT 38')
dict1['row_24'] = ('ADT 53','CO 51','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_25'] = ('CR 1009','CR 1009 Sub 1','ADT 51')
dict1['row_26'] = ('ADT 38','ADT 39','ADT 46','Co 50','Co 52','TKM 13','Improved white ponni','TRY 3')
dict1['row_27'] = ('TRY 1','TRY 2','TRY 36','Co 43')
dict1['row_28'] = ('ADT 53','CO 51','ADT 43','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16')
dict1['row_29'] = ('CO 52','TKM 13','VGD 1','CO 43','Imp.White Ponni','TNAU Rice Hybrid CO 4','CO (R) 50','ADT(R) 46','TNAU Rice ADT 49','ADT 39')
dict1['row_30'] = ('ADT 53','CO 51','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16')
dict1['row_31'] = ('ADT 53','CO 51','ADT 43','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_32'] = ('CR 1009 Sub1','TNAU Rice ADT 50','ADT 51','CR 1009')
dict1['row_33'] = ('VGD 1','TKM 13','CO 52','CO (R) 50','ADT 39','ADT 38','TNAU Rice ADT 49','CO 43','Imp.White Ponni','ADT (R) 46','TNAU Rice TRY 3*','TNAU Rice Hybrid CO 4','TRY 1*')
dict1['row_34'] = ('ADT 53','CO 51','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_35'] = ('ADT 38','ADT 39','ADT 46','Co 50','Co 52','TKM 13','Improved white ponni','TRY 3')
dict1['row_36'] = ('CR 1009','CR 1009 Sub 1','ADT 51')
dict1['row_37'] = ('ADT 38','ADT 39','ADT 46','Co 50','Co 52','TKM 13','Improved white ponni','TRY 3')
dict1['row_38'] = ('ADT 53','CO 51','ADT 43','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_39'] = ('VGD 1','TKM 13','CO 52','Imp.White Ponni','CO 43','TRY 1*','TNAU Rice TRY 3*','CO (R) 50','TNAU Rice ADT 49','TNAU Rice Hybrid CO 4')
dict1['row_40'] = ('ADT 53','CO 51','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_41'] = ('ADT 53','CO 51','ADT 43','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_42'] = ('VGD 1','TKM 13','CO 52','Paiyur 1','Imp.White Ponni','TNAU Rice ADT 49','ADT 39','ASD 19','CO 43')
dict1['row_43'] = ('ADT 53','CO 51','ADT (R) 45','TPS 5','MDU 6','ADT 36','ADT 37','CORH 3','ASD 16','TKM 9')
dict1['row_44'] = ('CO(R)50','CO 52','ADT 39')
dict1['row_45'] = ('ADT 53','CO 51','ADT 43','ADT (R) 45','TPS 5','ADT 36','ADT 37','CORH 3','ASD 16')
dict1['row_46'] = ('CR 1009 Sub1','TNAU Rice ADT 50','ADT 51','CR 1009')
dict1['row_47'] = ('VGD 1','TKM 13','CO 52','CO (R) 50','ADT 39','ADT 38','TNAU Rice ADT 49','CO 43','Imp.White Ponni','ADT (R) 46','TNAU Rice TRY 3*','TNAU Rice Hybrid CO 4')
dict1['row_48'] = ('CR 1009 Sub1','CR 1009','ADT 39')
dict1['row_49'] = ('ADT 38','ADT 39','ADT 46','Co 50','Co 52','TKM 13','Improved white ponni','TRY 3')
dict1['row_50'] = ('TRY 1','TRY 2','TRY 3','Co 43')
dict1['row_51'] = ('MDU 6','CO 51','ADT 53','ASD 16','MDU 5','ADT43','ADT(R)45')
dict1['row_52'] = ('VGD 1','TKM 13','CO 52','CO (R) 50','ADT 39','ADT 38','TNAU Rice ADT 49','CO 43','Imp.White Ponni','ADT (R) 46','TNAU Rice','TRY 3*','TNAU Rice Hybrid CO 4')
dict1['row_53'] = ('MDU 6','CO 51','ADT 53','ADT 36','ADT 37','ADT(R)45','ASD 16')
dict1['row_54'] = ('Anna (R) 4','MDU 5','PMK (R) 3')
dict1['row_55'] = ('Anna (R) 4','PMK 3')
dict1['row_56'] = ('Imp.White Ponni','TNAU Rice TRY 3','TRY 1*','VGD 1','TKM 13','CO 52','TNAU Rice Hybrid CO 4','CO (R) 50','CO 43','ADT 39')
dict1['row_57'] = ('Anna (R) 4','MDU 5','MDU 6','PMK (R) 3','ADT 36','ADT 53','CO 51')
dict1['row_58'] = ('Anna (R) 4','PMK 3')
dict1['row_59'] = ('VGD 1','TKM 13','CO 52','CO (R) 50','ADT 39','ADT 38','TNAU Rice ADT 49','CO 43','Imp.White Ponni','ADT (R) 46','TNAU Rice TRY 3*','TNAU Rice Hybrid CO 4')
dict1['row_60'] = ('Anna (R) 4','ADT 36','MDU 6','PMK (R) 3','ADT (R) 45')
dict1['row_61'] = ('Anna (R) 4','PMK 3')
dict1['row_62'] = ('ADT 36','MDU 6','PMK (R) 3','Anna (R) 4','ADT 53','CO 51','ADT 39','TKM 13','VGD 1')
dict1['row_63'] = ('TPS 5 ','ASD 16','ASD 18','ADT 53','CO 51','ADT 43','ADT (R) 45','ADT 36','ADT 37','CORH 3','TKM 9')
dict1['row_64'] = ('TPS 5','ASD 16','ASD 18','ADT 53','CO 51','ADT 43','ADT (R) 45','ADT 36','ADT 37','CORH 3','TKM 9')
dict1['row_65'] = ('TPS 3','ASD 19','VGD 1','TKM 13','CO 52','CO (R) 50','ADT 39','ADT 38','TNAU Rice ADT 49','CO 43','Imp.White Ponni','ADT (R) 46','TRY 1','TNAU Rice Hybrid CO 4')
dict1['row_66'] = ('Anna (R) 4','PMK (R) 3')
dict1['row_67'] = ('TPS 5','ASD 16','ADT 36','ASD 18','ADT 43','ADT(R) 45','CORH 3','ADT 53','CO 51')
dict1['row_68'] = ('ASD 19','TPS 3','CR 1009 Sub1','CR 1009','CO 43','TRY 1*','TNAU Rice TRY 3','VGD 1','TKM 13','ADT 39','CO 52','ADT (R) 46','TNAU Rice Hybrid CO 4','CO(R) 50','Imp.White Ponni','CO 43')
dict1['row_69'] = ('ADT 36','TKM 9')



# Tiruvarur    :  tir

Tiruvarur={} 

Tiruvarur['Kuruvai'] = 'row_1' 
Tiruvarur['Samba'] = 'row_2'
Tiruvarur['Late Samba'] = 'row_3'	
Tiruvarur['Thaladi'] = 'row_3'
Tiruvarur['Navarai'] = 'row_4'
Tiruvarur['semi_dry_cultivation_in_august'] = 'row_7'
Tiruvarur['semi_dry_cultivation_in_septemeber'] = 'row_8'
Tiruvarur['Flood_affected_areas'] = 'row_12'
Tiruvarur['Salt_affected_areas'] = 'row_13'


# Thanjavur    :  thr

Thanjavur={} 

Thanjavur['Kuruvai'] = 'row_1' 
Thanjavur['Samba'] = 'row_2'
Thanjavur['Late Samba'] = 'row_3'	
Thanjavur['Thaladi'] = 'row_3'
Thanjavur['Navarai'] = 'row_4'
Thanjavur['semi dry cultivation in august'] = 'row_7'
Thanjavur['semi dry cultivation in septemeber'] = 'row_8'
Thanjavur['Flood affected areas'] = 'row_12'
Thanjavur['Salt affected areas'] = 'row_13'





# Nagapattinam    :   np

Nagapattinam = {}

Nagapattinam['Late Kuruvai'] = 'row_5'
Nagapattinam['Samba'] = 'row_6'
Nagapattinam['Semi dry cultivation in august'] = 'row_7'
Nagapattinam['Semi dry cultivation in september'] = 'row_8'
Nagapattinam['Flood affected areas'] = 'row_12'
Nagapattinam['Salt affected areas'] = 'row_13'





# Tiruchirapalli    : tir

Tiruchirapalli = {}

Tiruchirapalli['Kuruvai'] = 'row_9'
Tiruchirapalli['Samba'] = 	'row_10'
Tiruchirapalli['Thaladi'] = 'row_10'
Tiruchirapalli['Summer'] = 'row_11'
Tiruchirapalli['Flood affected areas'] = 'row_12'
Tiruchirapalli['Salt affected areas'] = 'row_13'






# Kanchipuram   : kn

Kanchipuram = {}

Kanchipuram['Sornavari'] = 'row_14'
Kanchipuram['Samba'] = 'row_15'	
Kanchipuram['Late Samba'] = 'row_15' 
Kanchipuram['Navarai'] = 'row_16'	
Kanchipuram ['Rainfed direct seeded'] = 'row_17'	
Kanchipuram['Semi-dry'] = 'row_17'






# Tiruvallur   : tur

Tiruvallur = {}

Tiruvallur['Sornavari'] = 'row_14'
Tiruvallur['Samba'] = 'row_15'	
Tiruvallur['Late Samba'] = 'row_15'
Tiruvallur['Navarai'] = 'row_16'
Tiruvallur['Rainfed direct seeded'] = 'row_17'
Tiruvallur['Semi-dry'] = 'row_17'
Tiruvallur['Drought affected areas'] = 'row_18'


# Vellore   : vr

Vellore ={}

Vellore['Sornavari'] = 'row_19'
Vellore['Samba'] = 'row_20'
Vellore['Navarai'] = 'row_21'


# Tiruvannamalai    : tni

Tiruvannamalai = {}

Tiruvannamalai['Sornavari'] = 'row_19'
Tiruvannamalai['Samba'] = 'row_20'
Tiruvannamalai['Navarai'] = 'row_21'


# Cuddalore   : cu

Cuddalore = {}

Cuddalore['Sornavari'] = 'row_22'
Cuddalore['Samba'] = 'row_23'
Cuddalore['Navarai'] ='row_24'


# Villupuram   : vu


Villupuram = {}

Villupuram['Sornavari'] = 'row_22'
Villupuram['Samba'] = 'row_23'
Villupuram['Navarai'] ='row_24'


# Delta regions of Cuddalore   :  dcu


Delta_regions_of_Cuddalore = {}

Delta_regions_of_Cuddalore['Samba'] = 'row_25'
Delta_regions_of_Cuddalore['Late samba'] = 'row_26'
Delta_regions_of_Cuddalore['Thaladi'] = 'row_26'
Delta_regions_of_Cuddalore['Salt_affected_areas '] = 'row_27'


# Coimbatore    :  co

Coimbatore ={}

Coimbatore['Kar'] = 'row_28'
Coimbatore['Samba'] = 'row_29'
Coimbatore['Late Samba'] = 'row_29'
Coimbatore['Navarai'] = 'row_30'



# Tiruppur	: tpr

Tiruppur = {}

Tiruppur['Kar'] = 'row_28'
Tiruppur['Samba'] = 'row_29'
Tiruppur['Late Samba'] = 'row_29'
Tiruppur['Navarai'] = 'row_30'



# Erode   : er

Erode = {} 

Erode['Kar'] = 'row_28'
Erode['Samba'] = 'row_29'
Erode['Late Samba'] = 'row_29'
Erode['Navarai'] = 'row_30'



# Karur   : ka

Karur = {}


Karur['Kuruvai'] = 'row_31'
Karur['Samba'] = 'row_32'
Karur['Late Samba'] = 'row_33'
Karur['Thaladi'] = 'row_33'
Karur['Navarai'] = 'row_34'



# Delta regions of Karur   : dka

Delta_regions_of_Karur = {}

Delta_regions_of_Karur['Late Samba'] = 'row_35'




# Perambalur	: pr

Perambalur = {} 

Perambalur['Kuruvai'] = 'row_31'
Perambalur['Samba'] = 'row_32'
Perambalur['Late Samba'] = 'row_33'
Perambalur['Thaladi'] = 'row_33'
Perambalur['Navarai'] = 'row_34'






# Ariyalur    : ar

Ariyalur = {} 

Ariyalur['Kuruvai'] = 'row_31'
Ariyalur['Samba'] = 'row_32'
Ariyalur['Late Samba'] = 'row_33'
Ariyalur['Thaladi'] = 'row_33'
Ariyalur['Navarai'] = 'row_34'


# Delta regions of Ariyalur    :  dar

Delta_regions_of_Ariyalur = {}

Delta_regions_of_Ariyalur['Samba'] = 'row_36'
Delta_regions_of_Ariyalur['Late samba'] = 'row_37'
Delta_regions_of_Ariyalur['Thaladi'] = 'row_37'


# Salem   : sa

Salem = {}

Salem['Kar'] =  'row_38'
Salem['Samba'] =  'row_39'
Salem['Navarai'] =  'row_40'


# Namakkal    : na

Namakkal = {}

Namakkal['Kar'] =  'row_38'
Namakkal['Samba'] =  'row_39'
Namakkal['Navarai'] =  'row_40'



# Dharmapuri   : da

Dharmapuri = {} 

Dharmapuri['Kar'] = 'row_41'
Dharmapuri['Samba'] = 'row_42'
Dharmapuri['Late Samba'] = 'row_42'
Dharmapuri['Navarai'] = 'row_43'




# Krishnagiri    : kri

Krishnagiri = {} 

Krishnagiri['Kar'] = 'row_41'
Krishnagiri['Samba'] = 'row_42'
Krishnagiri['Late Samba'] = 'row_42'
Krishnagiri['Navarai'] = 'row_43'


# The Nilgiris    : nr

Nilgiris = {}

Nilgiris['Samba'] = 'row_44'




# Pudukottai     :  pu

Pudukottai = {} 

Pudukottai['Kuruvai']  =  'row_45'
Pudukottai['Samba']  =  'row_46'
Pudukottai['Late Samba'] =  'row_47'
Pudukottai['Thaladi'] =  'row_47'
Pudukottai['Rainfed direct seeded'] =  'row_48'
Pudukottai['Semi-dry'] =  'row_48'
Pudukottai['Salt affected areas'] = 'row_50'


# Delta regions of Pudukottai  : dpu

Delta_regions_of_Pudukottai = {}

Delta_regions_of_Pudukottai['All seasons'] =  'row_49'


# Madurai    :  ma 


Madurai = {}

Madurai['Kar'] = 'row_51'
Madurai['Samba'] = 'row_52'
Madurai['Late Samba'] = 'row_52'
Madurai['Navarai'] = 'row_53'
Madurai['Semi-dry'] = 'row_54'
Madurai['Drought affected areas'] = 'row_55'



# Dindigul   : di

Dindigul = {}

Dindigul['Kar'] = 'row_51'
Dindigul['Samba'] = 'row_52'
Dindigul['Late Samba'] = 'row_52'
Dindigul['Navarai'] = 'row_53'
Dindigul['Semi-dry'] = 'row_54'





# Theni   : th

Theni = {}

Theni['Kar'] = 'row_51'
Theni['Samba'] = 'row_52'
Theni['Late Samba'] = 'row_52'
Theni['Navarai'] = 'row_53'
Theni['Semi-dry'] = 'row_54'


# Ramanathapuram    : ra

Ramanathapuram = {} 

Ramanathapuram['Samba'] = 'row_56'
Ramanathapuram['Rainfed direct seeded'] = 'row_57'
Ramanathapuram['Semi-dry'] = 'row_57'
Ramanathapuram['Drought affected areas'] = 'row_58'


# Virudhunagar     :  vr


Virudhunagar = {}


Virudhunagar['Samba'] = 'row_59'
Virudhunagar['Rainfed direct seeded'] = 'row_60'
Virudhunagar['Drought affected areas'] = 'row_61'


# Sivaganga   : si 

Sivaganga = {}

Sivaganga['Semi-dry'] = 'row_62'



# Tirunelveli   :  ti 

Tirunelveli = {}

Tirunelveli['Early kar'] = 'row_63'
Tirunelveli['Kar'] = 'row_64'
Tirunelveli['Pishanam'] = 'row_65'
Tirunelveli['Late Pishanam'] = 'row_65'
Tirunelveli['Semi-dry'] = 'row_66'


# Thoothukudi    : thi

Thoothukudi = {}

Thoothukudi['Early kar'] = 'row_63'
Thoothukudi['Kar'] = 'row_64'
Thoothukudi['Pishanam'] = 'row_65'
Thoothukudi['Late Pishanam'] = 'row_65'
Thoothukudi['Semi-dry'] = 'row_66'


# Kanyakumari    : kan

Kanyakumari = {}

Kanyakumari['Kar'] = 'row_67'
Kanyakumari['Pishanam'] = 'row_68'
Kanyakumari['Late samba'] = 'row_68'
Kanyakumari['Semi-dry'] = 'row_69'



def predict(b,a):

	if b == 'Tiruvarur':
		b1 = Tiruvarur[a]
	if b == 'Thanjavur':
		b1 = Thanjavur[a]	
	if b == 'Nagapattinam':
		b1 = Nagapattinam[a]
	if b == 'Tiruchirapalli':
		b1 = Tiruchirapalli[a]
	if b == 'Kanchipuram':
		b1 = Kanchipuram[a]	
	if b == 'Tiruvallur':
		b1 = Tiruvallur[a]	
	if b == 'Vellore':
		b1 = Vellore[a]
	if b == 'Tiruvannamalai':
		b1 = Tiruvannamalai[a]	
	if b == 'Cuddalore':
		b1 = Cuddalore[a]
	if b == 'Villupuram':
		b1 = Villupuram[a]
	if b == 'Delta_regions_of_Cuddalore':
		b1 = Delta_regions_of_Cuddalore[a]	
	if b == 'Coimbatore':
		b1 = Coimbatore[a]	
	if b == 'Tiruppur':
		b1 = Tiruppur[a]
	if b == 'Erode':
		b1 = Erode[a]	
	if b == 'Karur':
		b1 = Karur[a]
	if b == 'Delta_regions_of_Karur':
		b1 = Delta_regions_of_Karur[a]
	if b == 'Perambalur':
		b1 = Perambalur[a]	
	if b == 'Ariyalur':
		b1 = Ariyalur[a]	
	if b == 'Delta_regions_of_Ariyalur':
		b1 = Delta_regions_of_Ariyalur[a]
	if b == 'Salem':
		b1 = Salem[a]	
	if b == 'Namakkal':
		b1 = Namakkal[a]
	if b == 'Dharmapuri':
		b1 = Dharmapuri[a]
	if b == 'Krishnagiri':
		b1 = Krishnagiri[a]	
	if b == 'Nilgiris':
		b1 = Nilgiris[a]	
	if b == 'Pudukottai':
		b1 = Pudukottai[a]
	if b == 'Delta_regions_of_Pudukottai':
		b1 = Delta_regions_of_Pudukottai[a]	
	if b == 'Madurai':
		b1 = Madurai[a]
	if b == 'Dindigul':
		b1 = Dindigul[a]
	if b == 'Theni':
		b1 = Theni[a]	
	if b == 'Ramanathapuram':
		b1 = Ramanathapuram[a]	
	if b == 'Virudhunagar':
		b1 = Virudhunagar[a]
	if b == 'Sivaganga':
		b1 = Sivaganga[a]	
	if b == 'Tirunelveli':
		b1 = Tirunelveli[a]
	if b == 'Thoothukudi':
		b1 = Thoothukudi[a]
	if b == 'Kanyakumari':
		b1 = Kanyakumari[a]
	
		
		
	d = dict1[b1]

	return d









app = Flask(__name__)

@app.route('/')
def welcome():
    return render_template('index.html')





@app.route('/submit', methods = ['POST','GET'])
def submit():


    if request.method=='POST':
        District = request.form['District']
        Season = str(request.form['Season'])
        variety = predict(District,Season)
    return render_template('index.html',variety = variety)






if __name__ == "__main__":
    app.run()